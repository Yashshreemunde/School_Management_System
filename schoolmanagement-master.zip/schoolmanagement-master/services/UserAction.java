package com.example.PROJECT.services;

public interface UserAction {

}
