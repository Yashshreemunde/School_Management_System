export class HighSchool
 {
    
    "schoolRegno": number;
    "schoolName":string;
    "schoolLocation":string;
    "noOfStudents":number;
    "noOfTeachers" : number;
    "schoolMailId":"string";
}
