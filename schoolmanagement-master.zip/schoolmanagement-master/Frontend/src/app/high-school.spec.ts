import { HighSchool } from './high-school';

describe('HighSchool', () => {
  it('should create an instance', () => {
    expect(new HighSchool()).toBeTruthy();
  });
});
